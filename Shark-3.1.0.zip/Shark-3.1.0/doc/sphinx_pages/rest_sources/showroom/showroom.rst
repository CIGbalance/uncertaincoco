Application examples
====================

This page illustrates some of the numerous real-world applications
that have been mastered using the Shark library.

.. todo::
    The application examples page will be part of the full, official 
    Shark release.
