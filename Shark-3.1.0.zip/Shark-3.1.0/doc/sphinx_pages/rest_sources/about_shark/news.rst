News
====


Shark 3.0.0 Released
^^^^^^^^^^^^^^^^^^^^^^^^

We are happy to announce the release of Shark 3.0.0

Shark moves to GitHub
^^^^^^^^^^^^^^^^^^^^^^^^

Today, Shark moved to GitHub, please update your repositories, see the downloads page for more details.

Shark goes LGPL
^^^^^^^^^^^^^^^

As of January 2014, Shark is distributed under the permissive
`GNU Lesser General Public License <http://www.gnu.org/copyleft/lesser.html>`_.

.. image:: images/lgplv3-147x51.png


Gold Prize for Shark alpha-release
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
**October 22, 2011:**
We are happy to announce that our alpha-release of Shark 3.0 has won
the Gold Prize at this year's `Open Source Software World Challenge 2011 <http://www.ossaward.org/>`_.
