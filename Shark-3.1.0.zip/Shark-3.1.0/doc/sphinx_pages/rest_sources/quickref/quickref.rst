Overview over Shark Quick Reference Sheets
==========================================

In addition to the Shark :doc:`tutorials <../tutorials/tutorials>`,
we provide quick reference (or "cheat") sheets on often-needed topics.
While the tutorials look at certain scenarios or tasks in-depths, the
quick references offer the most important syntax or interfaces without
many words.

The following quick references are available:

* :doc:`data_qr`

