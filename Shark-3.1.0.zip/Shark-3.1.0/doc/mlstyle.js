MathJax.Hub.Config({
  TeX: {
    Macros: {
      vec: ["{\\bf #1}",1]
    }
  }
});

MathJax.Hub.Configured();
//nicked from https://groups.google.com/forum/#!msg/mathjax-users/J-36V22-G9Q/AW3ncCbJzS8J
